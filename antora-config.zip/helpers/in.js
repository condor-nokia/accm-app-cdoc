'use strict'

module.exports = (value, ...values) => Array.from(values).includes(value)
